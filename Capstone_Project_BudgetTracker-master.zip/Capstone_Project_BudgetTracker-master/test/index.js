var assert = require('chai').assert;
var first = require('../index.js');

describe('Login', function(){
	it('it should return emailId and Password', function(){
		assert.equal(first(),'taha.saifee@wipro.com&1234567')
	});
	
});
