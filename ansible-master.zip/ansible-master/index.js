var email='taha.saifee@wipro.com'
var pass='1234567'
module.exports = function(){
	return email+'&'+pass;
}
