var webdriver = require('selenium-webdriver');
	var driver = new webdriver.Builder().forBrowser('firefox').build();
	var assert = require('assert');
	driver.get('http://localhost:8090/').then(function(){
			return driver.getTitle();
		}).
		then( function(title){
			assert.equal("Login Page", title);
		}).
		then(function(){

				console.log('successfully opening Budget Dashboard page');
				return driver.quit;
		});


	/*driver.get('http://localhost:8090/').
		then(function(){
			return driver.findElement( {xpath : '/html/body/form/button'}).click();
		}).
		then(function(){
			return driver.switchTo().alert().getText();
		}).
		then( function(alertMessage){
			assert.equal("User is not registered", alertMessage);
				
		}).
		then(function(){

				console.log('successfully login');
				return driver.sleep(5000);

			}).
		then(function(){
			return driver.quit();
		});*/



	/*driver.get('http://localhost:8090/registration.html').
		then(function(){
			return driver.findElement({xpath : '/html/body/form/button'}).click();
		}).
		then(function(){
			
			return driver.getCurrentUrl();
		}).
		then( function(url){
			assert.equal("http://localhost:8090/index.html", url);
		}).
		then(function(){

				console.log('successfully clicking on registration button');
				return driver.sleep(5000);

			}).
		then(function(){
			return driver.quit();
		});*/

