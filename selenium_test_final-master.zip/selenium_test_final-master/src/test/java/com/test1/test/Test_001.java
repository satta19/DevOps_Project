package com.test1.test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Test_001 {
	
	static FirefoxDriver driver ;
	
	@BeforeTest
	
	public void open_app()
	{
		String url="http://localhost:8090";
		FirefoxBinary firefoxBinary = new FirefoxBinary();
        firefoxBinary.addCommandLineOptions("--headless"); 
        System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBinary(firefoxBinary);
        
         driver = new FirefoxDriver(firefoxOptions);
        
        driver.get(url);
        

	}
	
	@Test
	public void verifytitle()
	{
		String title="Budget SignIn";
		Assert.assertEquals(driver.getTitle(), title);
	}
	
	@Test
	public void createAccountPage()
	{
		WebElement button = driver.findElement(By.xpath("/html/body/form/a"));
        button.click();
        
        WebElement first_name = driver.findElement(By.id("firstName"));
        WebElement last_name = driver.findElement(By.id("emailID"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement cpass_name = driver.findElement(By.id("conform_password"));
        first_name.sendKeys("Sourav");
        last_name.sendKeys("satta@gmail.com");
        password.sendKeys("Atta123!");
        cpass_name.sendKeys("Atta123!");
        
        WebElement button1 = driver.findElement(By.xpath("/html/body/form/button"));
        button1.click();
         
        Assert.assertTrue(driver.getTitle().contains("Budget SignIn"));

	}
	
	

}
